package com.example.sih;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomeActivity extends AppCompatActivity {

    ImageView camera;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(HomeActivity.this);
        setContentView(R.layout.home_page);






    }

    public void cameraopen(View view) {

        Intent cameraopen = new Intent(HomeActivity.this, TranslateActivity.class);

        startActivity(cameraopen);

    }

    public void openlearningpage(View view) {

        Intent learningopen = new Intent(HomeActivity.this, LearningPage.class);
        startActivity(learningopen);
    }

    public void opentranslate(View view) {

        Intent translateopen = new Intent(HomeActivity.this, TranslateActivity.class);
        startActivity(translateopen);
    }


    public void openprofile(View view) {

        Intent profileopen = new Intent(HomeActivity.this, ProfilePage.class);
        startActivity(profileopen);
    }
}
