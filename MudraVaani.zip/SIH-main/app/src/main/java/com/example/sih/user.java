package com.example.sih;

// User.java
public class user {
    private String username;
    private String password;

    //constructor
    public user(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getusername() {
        return username;
    }

    public String getpassword() {
        return password;
    }

    //user data array
    public static user[] Mainusers = {
            new user("user1", "password1"),
            new user("user2", "password2"),
            new user("user3", "password3"),
            new user("user4", "password4"),
            new user("user5", "password5"),
            new user("user6", "password6")

    };

}



