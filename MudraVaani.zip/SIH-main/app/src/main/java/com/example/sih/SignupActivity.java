package com.example.sih;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//extending MainActivity with SignupActivity
public class SignupActivity extends MainActivity {

    EditText dobbutton;
    Button signupbutton;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(SignupActivity.this);
        setContentView(R.layout.signup_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.signup), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dobbutton = findViewById(R.id.dobselect);
        signupbutton = findViewById(R.id.signupbutton);


        dobbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatePickerDialog datePickerDialog = new DatePickerDialog(SignupActivity.this);
                datePickerDialog.show();
                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayofmonth) {
                        String String_year = String.valueOf(year);
                        String String_month = String.valueOf(month+1);
                        String String_dayOfMonth = String.valueOf(dayofmonth);
                        dobbutton.setText("DOB : " + String_dayOfMonth+"/" +String_month+"/" + String_year);

                    }
                });
            }
        });






    }
}
