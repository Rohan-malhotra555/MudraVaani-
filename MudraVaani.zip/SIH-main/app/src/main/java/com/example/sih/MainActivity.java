package com.example.sih;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;




public class MainActivity extends AppCompatActivity {

    Button loginbutton,signupbutton;
    EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginbutton = findViewById(R.id.loginbutton);
        signupbutton = findViewById(R.id.signupbutton);
    }

    public void signupfunc(View view){

        Intent signupintent = new Intent(MainActivity.this, SignupActivity.class);
        startActivity(signupintent);
    }



    public void loginfunc(View view){

        String typedusername = username.getText().toString();
        String typedpassword = password.getText().toString();


        for (user currentuser : user.Mainusers) {
            if(currentuser.getusername().equals(typedusername) & currentuser.getpassword().equals(typedpassword))
            {
                Toast.makeText(MainActivity.this,"Accesss Granted",Toast.LENGTH_SHORT).show();
                Intent logintohome = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(logintohome);
                break;
            }

            else
            {
                Toast.makeText(MainActivity.this,"Accesss Denied",Toast.LENGTH_SHORT).show();
                break;
            }
        }


    }



}